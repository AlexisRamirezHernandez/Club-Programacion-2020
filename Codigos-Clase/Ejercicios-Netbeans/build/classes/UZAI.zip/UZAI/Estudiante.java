/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UZAI;

/**
 *
 * @author lito_
 */
public class Estudiante extends Persona{
    private String numeroControl, carrera, semestre;
    
    public Estudiante(String nombre,String apellido, String curp,int edad,int numeroControl,String semestre,String carrera){
        super(nombre,apellido,curp,edad,numeroControl,semestre,carrera,"No disponible","No disponible");
    }
    
    public String mostrarDatos(){
        String str="Numero de control: "+
        numeroControl+"\nDe la carrera: "+carrera+"\nSemestre: "+semestre;
        return str;
    }
}
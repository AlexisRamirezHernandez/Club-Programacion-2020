/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UZAI;

/**
 *
 * @author lito_
 */
public class Empleado extends Persona{
    private String area, sueldo;
    
    public Empleado(String nombre,String apellido,String curp, int edad, String sueldo, String area){
        
        super(nombre,apellido,curp,edad,-1,"No Disponible","No disponible",sueldo,area);
    }
    
    
    public String mostrarDatos(){
        
        String str="Area: "+
        getArea()+"\nSueldo: "+getSueldo();
        return str; 
    }
}